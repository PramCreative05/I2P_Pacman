#ifndef SCENE_OVER_H
#define SCENE_OVER_H

#include "game.h"
#include "shared.h"

Scene scene_over_create(void);

#endif
